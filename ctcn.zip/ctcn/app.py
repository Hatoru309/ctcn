# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from db import create_report, update_report, list_reports, update_status
import joblib

app = Flask(__name__)
CORS(app)

# Load the trained model, vectorizer, and label encoder
print("Loading ML models...")
try:
    svm_model = joblib.load('svm_model.pkl')
    vectorizer = joblib.load('tfidf_vectorizer.pkl')
    label_encoder = joblib.load('label_encoder.pkl')
    print("Models loaded successfully!")
except Exception as e:
    print(f"Error loading models: {e}")
    svm_model = None
    vectorizer = None
    label_encoder = None

def predict_urgency(message):
    """Predict urgency label for a message using the trained model"""
    if svm_model is None or vectorizer is None or label_encoder is None:
        # Fallback if models are not loaded
        return "Medium", 0.5, {}
    
    try:
        # Transform message to TF-IDF features
        message_tfidf = vectorizer.transform([str(message)])
        
        # Predict label
        prediction = svm_model.predict(message_tfidf)
        
        # Get probability estimates
        probability = svm_model.predict_proba(message_tfidf)[0]
        
        # Decode predicted label
        predicted_label = label_encoder.inverse_transform(prediction)[0]
        
        # Get confidence (probability of predicted class)
        confidence = float(probability[prediction[0]])
        
        # Get all probabilities as dictionary
        all_probs = dict(zip(label_encoder.classes_, probability))
        
        return predicted_label, confidence, all_probs
    except Exception as e:
        print(f"Error predicting urgency: {e}")
        return "Medium", 0.5, {}

# -------------------------------
# 1. POST /api/report — gửi báo cứu hộ
# -------------------------------
@app.route('/api/report', methods=['POST'])
def report_create():
    data = request.get_json()
    required = ["phone", "lat", "lng", "message"]
    for field in required:
        if field not in data:
            return jsonify({"ok": False, "error": f"{field} is required"}), 400
    
    # Predict urgency label for the message
    message = data.get("message", "")
    urgency_label, confidence, all_probs = predict_urgency(message)
    
    # Add urgency information to the data
    data['urgency'] = urgency_label
    data['urgency_confidence'] = confidence
    data['urgency_probs'] = all_probs
    
    created = create_report(data)
    return jsonify({"ok": True, "report": created}), 201

# -------------------------------
# 2. PUT /api/report/update — cập nhật báo
# -------------------------------
@app.route('/api/report/update', methods=['PUT'])
def report_update():
    data = request.get_json()
    if "id" not in data and "phone" not in data:
        return jsonify({"ok": False, "error": "id or phone is required"}), 400
    
    # If message is updated, re-predict urgency
    if "message" in data:
        message = data.get("message", "")
        urgency_label, confidence, all_probs = predict_urgency(message)
        data['urgency'] = urgency_label
        data['urgency_confidence'] = confidence
        data['urgency_probs'] = all_probs
    
    updated = update_report(data)
    if updated is None:
        return jsonify({"ok": False, "error": "report not found"}), 404
    return jsonify({"ok": True, "report": updated})

# -------------------------------
# 3. GET /api/rescue/list — danh sách báo cứu hộ
# -------------------------------
@app.route('/api/rescue/list', methods=['GET'])
def rescue_list():
    reports = list_reports()
    return jsonify({"ok": True, "reports": reports})

# -------------------------------
# 4. PUT /api/rescue/update-status — đổi trạng thái
# -------------------------------
@app.route('/api/rescue/update-status', methods=['PUT'])
def rescue_update_status():
    data = request.get_json()
    report_id = data.get("id")
    status = data.get("status")
    allowed_status = ["pending", "processing", "done", "holding"]
    if status not in allowed_status:
        return jsonify({"ok": False, "error": "Invalid status"}), 400
    updated = update_status(report_id, status)
    if updated is None:
        return jsonify({"ok": False, "error": "report not found"}), 404
    return jsonify({"ok": True, "report": updated})

# -------------------------------
# Healthcheck
# -------------------------------
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "ok"})

# -------------------------------
# Run server
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True, port=5000)
