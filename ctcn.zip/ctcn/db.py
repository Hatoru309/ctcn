# db.py
from datetime import datetime
import uuid
import sqlite3
import json
import os

# Database file path
DB_FILE = "reports.db"

# Urgency priority order (higher number = more urgent)
URGENCY_PRIORITY = {
    "Critical": 4,
    "High": 3,
    "Medium": 2,
    "Low": 1
}

def get_db_connection():
    """Create and return a database connection"""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row  # This allows column access by name
    return conn

def init_db():
    """Initialize the database and create tables if they don't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reports (
            id TEXT PRIMARY KEY,
            phone TEXT NOT NULL,
            lat REAL NOT NULL,
            lng REAL NOT NULL,
            message TEXT NOT NULL,
            ts TEXT,
            meta TEXT,  -- JSON string
            status TEXT NOT NULL DEFAULT 'pending',
            urgency TEXT NOT NULL DEFAULT 'Medium',
            urgency_confidence REAL NOT NULL DEFAULT 0.0,
            urgency_probs TEXT,  -- JSON string
            created_at TEXT NOT NULL
        )
    ''')
    
    # Create index for faster queries
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_status ON reports(status)
    ''')
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_urgency ON reports(urgency)
    ''')
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_created_at ON reports(created_at)
    ''')
    
    conn.commit()
    conn.close()

def get_urgency_priority(urgency):
    """Get priority value for sorting (higher = more urgent)"""
    return URGENCY_PRIORITY.get(urgency, 0)

def row_to_dict(row):
    """Convert a database row to a dictionary"""
    if row is None:
        return None
    
    report = {
        "id": row["id"],
        "phone": row["phone"],
        "lat": row["lat"],
        "lng": row["lng"],
        "message": row["message"],
        "ts": row["ts"],
        "meta": json.loads(row["meta"]) if row["meta"] else {},
        "status": row["status"],
        "urgency": row["urgency"],
        "urgency_confidence": row["urgency_confidence"],
        "urgency_probs": json.loads(row["urgency_probs"]) if row["urgency_probs"] else {},
        "created_at": row["created_at"]
    }
    return report

def create_report(data):
    """Create a new report in the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    report_id = str(uuid.uuid4())
    created_at = datetime.utcnow().isoformat()
    
    new_report = {
        "id": report_id,
        "phone": data.get("phone"),
        "lat": data.get("lat"),
        "lng": data.get("lng"),
        "message": data.get("message"),
        "ts": data.get("ts"),
        "meta": json.dumps(data.get("meta", {})),
        "status": "pending",  # default
        "urgency": data.get("urgency", "Medium"),
        "urgency_confidence": data.get("urgency_confidence", 0.0),
        "urgency_probs": json.dumps(data.get("urgency_probs", {})),
        "created_at": created_at
    }
    
    cursor.execute('''
        INSERT INTO reports (id, phone, lat, lng, message, ts, meta, status, 
                           urgency, urgency_confidence, urgency_probs, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        new_report["id"],
        new_report["phone"],
        new_report["lat"],
        new_report["lng"],
        new_report["message"],
        new_report["ts"],
        new_report["meta"],
        new_report["status"],
        new_report["urgency"],
        new_report["urgency_confidence"],
        new_report["urgency_probs"],
        new_report["created_at"]
    ))
    
    conn.commit()
    conn.close()
    
    # Return the report as a dictionary (same format as before)
    return {
        "id": report_id,
        "phone": data.get("phone"),
        "lat": data.get("lat"),
        "lng": data.get("lng"),
        "message": data.get("message"),
        "ts": data.get("ts"),
        "meta": data.get("meta", {}),
        "status": "pending",
        "urgency": data.get("urgency", "Medium"),
        "urgency_confidence": data.get("urgency_confidence", 0.0),
        "urgency_probs": data.get("urgency_probs", {}),
        "created_at": created_at
    }

def update_report(data):
    """Update an existing report in the database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Find the report by id or phone
    report_id = data.get("id")
    phone = data.get("phone")
    
    if report_id:
        cursor.execute('SELECT * FROM reports WHERE id = ?', (report_id,))
    elif phone:
        cursor.execute('SELECT * FROM reports WHERE phone = ? ORDER BY created_at DESC LIMIT 1', (phone,))
    else:
        conn.close()
        return None
    
    row = cursor.fetchone()
    if row is None:
        conn.close()
        return None
    
    # Build update query dynamically based on provided fields
    update_fields = []
    update_values = []
    
    if "message" in data:
        update_fields.append("message = ?")
        update_values.append(data["message"])
    
    if "lat" in data:
        update_fields.append("lat = ?")
        update_values.append(data["lat"])
    
    if "lng" in data:
        update_fields.append("lng = ?")
        update_values.append(data["lng"])
    
    if "meta" in data:
        update_fields.append("meta = ?")
        update_values.append(json.dumps(data["meta"]))
    
    if "urgency" in data:
        update_fields.append("urgency = ?")
        update_values.append(data["urgency"])
    
    if "urgency_confidence" in data:
        update_fields.append("urgency_confidence = ?")
        update_values.append(data["urgency_confidence"])
    
    if "urgency_probs" in data:
        update_fields.append("urgency_probs = ?")
        update_values.append(json.dumps(data["urgency_probs"]))
    
    if update_fields:
        # Use the id from the found row
        update_values.append(row["id"])
        cursor.execute(f'''
            UPDATE reports 
            SET {', '.join(update_fields)}
            WHERE id = ?
        ''', update_values)
        conn.commit()
        
        # Fetch updated row
        cursor.execute('SELECT * FROM reports WHERE id = ?', (row["id"],))
        updated_row = cursor.fetchone()
        conn.close()
        return row_to_dict(updated_row)
    
    conn.close()
    return row_to_dict(row)

def list_reports():
    """List all reports sorted by urgency, status, confidence, and creation time"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM reports ORDER BY created_at DESC')
    rows = cursor.fetchall()
    conn.close()
    
    # Convert rows to dictionaries
    reports = [row_to_dict(row) for row in rows]
    
    # Status priority order (higher number = more priority)
    STATUS_PRIORITY = {
        "pending": 4,
        "processing": 3,
        "holding": 2,
        "done": 1
    }
    
    def get_status_priority(status):
        """Get priority value for status sorting (higher = more priority)"""
        return STATUS_PRIORITY.get(status, 0)
    
    # Sort reports by:
    # 1. Urgency (Critical > High > Medium > Low)
    # 2. Status (pending > processing > holding > done)
    # 3. Confidence (higher confidence first)
    # 4. Creation time (newer first)
    def get_sort_key(x):
        created_at = x.get("created_at", "")
        # Convert ISO timestamp to epoch time (larger = newer)
        try:
            # Handle both with and without timezone
            ts_str = created_at.replace('Z', '+00:00') if created_at else ''
            timestamp_value = datetime.fromisoformat(ts_str).timestamp() if ts_str else 0
        except:
            # Fallback: use string hash if parsing fails
            timestamp_value = hash(created_at) if created_at else 0
        return (
            -get_urgency_priority(x.get("urgency", "Medium")),  # Negative for descending (Critical first)
            -get_status_priority(x.get("status", "pending")),  # Negative for descending (pending first)
            -x.get("urgency_confidence", 0.0),  # Negative for descending (higher confidence first)
            -timestamp_value  # Negative so newer (larger timestamp) comes first
        )
    
    sorted_reports = sorted(reports, key=get_sort_key)
    return sorted_reports

def update_status(report_id, status):
    """Update the status of a report"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM reports WHERE id = ?', (report_id,))
    row = cursor.fetchone()
    
    if row is None:
        conn.close()
        return None
    
    cursor.execute('UPDATE reports SET status = ? WHERE id = ?', (status, report_id))
    conn.commit()
    
    # Fetch updated row
    cursor.execute('SELECT * FROM reports WHERE id = ?', (report_id,))
    updated_row = cursor.fetchone()
    conn.close()
    
    return row_to_dict(updated_row)

# Initialize database when module is imported
init_db()
